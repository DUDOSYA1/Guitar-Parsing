import sqlite3
import pandas as pd
from normalizer import GuitarNormalizer

DB_PATH = "thomann_guitars.db"


def process_database():
    print("🔄 Подключение к БД...")
    conn = sqlite3.connect(DB_PATH)

    print("📥 Чтение данных...")
    df = pd.read_sql_query("SELECT * FROM guitars", conn)

    print(f"Найдено записей: {len(df)}")

    normalizer = GuitarNormalizer()

    normalized_rows = []

    print("⚙️ Нормализация...")

    for i, (_, row) in enumerate(df.iterrows()):
        record = row.to_dict()

        normalized = normalizer.normalize(record)

        if normalized["model"] == "unknown":
            print(f"⚠️ Не распознано: {record['model']}")

        normalized_rows.append(normalized)

        if i % 100 == 0:
            print(f"Обработано: {i}")

    result_df = pd.DataFrame(normalized_rows)

    print("💾 Сохранение в БД...")
    result_df.to_sql("guitars_normalized", conn, if_exists="replace", index=False)

    print("💾 Сохранение в CSV...")
    result_df.to_csv("normalized_guitars.csv", index=False)

    conn.close()

    print("✅ ГОТОВО!")
    print("Создано:")
    print("- таблица: guitars_normalized")
    print("- файл: normalized_guitars.csv")


if __name__ == "__main__":
    process_database()