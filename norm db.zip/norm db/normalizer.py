import re
from typing import Dict


class GuitarNormalizer:
    def __init__(self):
        # ===== МОДЕЛИ ПО БРЕНДАМ =====
        self.brand_models = {
            "fender": ["stratocaster", "telecaster"],
            "squier": ["stratocaster", "telecaster"],
            "gibson": ["les paul", "sg"],
            "epiphone": ["les paul", "sg"],
            "prs": ["custom", "se"],
        }

        # fallback (если бренд неизвестен)
        self.model_map = {
            "strat": "stratocaster",
            "tele": "telecaster",
            "les paul": "les paul",
            "lp": "les paul",
            "sg": "sg",
            "sc": "single cut"
        }

        self.pickups = ["hss", "hh", "sss", "p90"]

        self.colors = {
            "sbk": "black",
            "bk": "black",
            "black": "black",
            "sb": "sunburst",
            "sunburst": "sunburst",
            "3ts": "sunburst",
            "white": "white",
            "wh": "white",
            "blue": "blue",
            "bl": "blue",
            "red": "red",
            "rd": "red",
            "gt": "gold top"
        }

        self.series_words = ["standard", "classic", "deluxe", "vintage"]

    # =========================
    def clean_text(self, text: str) -> str:
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s\-"]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    # =========================
    def normalize_brand(self, brand: str) -> str:
        return brand.lower().strip()

    # =========================
    def extract_model(self, text: str, brand: str) -> str:
        # ===== BRAND-AWARE =====

        if brand in ["fender", "squier"]:
            if "strat" in text:
                return "stratocaster"
            if "tele" in text:
                return "telecaster"

        if brand in ["gibson", "epiphone"]:
            if "les paul" in text or "lp" in text:
                return "les paul"
            if "sg" in text:
                return "sg"

        if brand == "harley benton":
            if "st-" in text:
                return "stratocaster"
            if "sc-" in text:
                return "single cut"
            if "te-" in text:
                return "telecaster"

        # ===== PRS =====
        if brand == "prs":
            if "custom" in text:
                return "custom"
            if "se" in text:
                return "se"
            return "prs model"

        # ===== FALLBACK =====
        if "strat" in text:
            return "stratocaster"
        if "tele" in text:
            return "telecaster"
        if "les paul" in text or "lp" in text:
            return "les paul"
        if "sg" in text:
            return "sg"
        if "sc-" in text:
            return "single cut"

        return "unknown"

    # =========================
    def extract_series(self, text: str) -> str:
        match = re.search(r'(st-\d+|sc-\d+)', text)
        if match:
            return match.group(1)

        for word in self.series_words:
            if word in text:
                return word

        return None

    # =========================
    def extract_pickup(self, text: str) -> str:
        for p in self.pickups:
            if p in text:
                return p
        return None

    # =========================
    def extract_color(self, text: str) -> str:
        for key, value in self.colors.items():
            if key in text:
                return value
        return None

    # =========================
    def extract_artist(self, raw_text: str) -> str:
        match = re.search(r'"([^"]+)"', raw_text)
        if match:
            return match.group(1)
        return None

    # =========================
    def normalize(self, record: Dict) -> Dict:
        raw_model = record.get("model", "")
        brand = self.normalize_brand(record.get("manufacturer", ""))

        clean = self.clean_text(raw_model)

        model = self.extract_model(clean, brand)

        result = {
            "brand": brand,
            "model": model,
            "series": self.extract_series(clean),
            "pickup": self.extract_pickup(clean),
            "color": self.extract_color(clean),
            "artist": self.extract_artist(raw_model),
            "price": record.get("price"),
            "condition": record.get("condition")
        }

        result["canonical_key"] = self.build_key(result)

        return result

    # =========================
    def build_key(self, data: Dict) -> str:
        parts = [
            data.get("brand"),
            data.get("model"),
            data.get("series"),
            data.get("pickup")
        ]

        return "_".join([p for p in parts if p])